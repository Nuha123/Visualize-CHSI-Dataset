#General Clustering
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(2:6)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

dataset <- read.csv("CancerTotalSum.csv")
# Fitting K-Means to the dataset
set.seed(29)
kmeans = kmeans(dataset[2:6], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"ClusteredCancer.csv",row.names=FALSE)
p <- read.csv("ClusteredCancer.csv")


#Clustering based on age
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(2)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[2], centers = 3)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 1-14 Cancer.csv",row.names=FALSE)
p <- read.csv("Age 1-14 Cancer.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(3)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[3], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 15-24 Cancer.csv",row.names=FALSE)
p <- read.csv("Age 15-24 Cancer.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(4)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[4], centers = 3)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 25-44 Cancer.csv",row.names=FALSE)
p <- read.csv("Age 25-44 Cancer.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(5)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[5], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 45-64 Cancer.csv",row.names=FALSE)
p <- read.csv("Age 45-64 Cancer.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(CancerTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(6)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[6], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 65+ Cancer.csv",row.names=FALSE)
p <- read.csv("Age 65+ Cancer.csv")


