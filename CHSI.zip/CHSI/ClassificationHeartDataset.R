dataset <- read_xlsx("CommonDataset2.xlsx")
data <- dataset[1]
n<-nrow(data)
print(n)
a<-c()
#state names
for (i in 1:n) {
  a[i]<-data$CHSI_State_Name[i]
}
#print(a)
final<-unique(a)
print(final)
k<-1
s1<-c()
s2<-c()
s3<-c()
s4<-c()
s5<-c()
s6<-c()
sum1<-0
sum2<-0
sum3<-0
sum4<-0
sum5<-0
sum6<-0
for(i in 1:51){
  for(j in k:n){
    if(final[i]==data$CHSI_State_Name[j]){
      if(dataset$No_Exercise[j]>0)
        sum1<-sum1+dataset$No_Exercise[j]
      if(dataset$Few_Fruit_Veg[j]>0)
        sum2<-sum2+dataset$Few_Fruit_Veg[j]
      if(dataset$Obesity[j]>0)
        sum3<-sum3+dataset$Obesity[j]
      if(dataset$High_Blood_Pres[j]>0)
        sum4<-sum4+dataset$High_Blood_Pres[j]
      if(dataset$Smoker[j]>0)
        sum5<-sum5+dataset$Smoker[j]
      if(dataset$Diabetes[j]>0)
        sum6<-sum6+dataset$Diabetes[j]
      j<-j+1
    }
    else{
      k<-j
      break
    }
  }
  
  s1[i]<-sum1/100
  s2[i]<-sum2/100
  s3[i]<-sum3/100
  s4[i]<-sum4/100
  s5[i]<-sum5/100
  s6[i]<-sum6/100
  sum1<-0
  sum2<-0
  sum3<-0
  sum4<-0
  sum5<-0
  sum6<-0
}
t<-cbind(final,s1,deparse.level = 1)
t<-cbind(t,s2,deparse.level = 1)
t<-cbind(t,s3,deparse.level = 1)
t<-cbind(t,s4,deparse.level = 1)
t<-cbind(t,s5,deparse.level = 1)
t<-cbind(t,s6,deparse.level = 1)


dataset1 <- read_csv("ClusteredHeart.csv")
data <- dataset1[2]
t<-cbind(t,data,deparse.level = 1)

bs <- data.frame(t)
write.csv(bs,"ClassificationHeart.csv",row.names=FALSE)

