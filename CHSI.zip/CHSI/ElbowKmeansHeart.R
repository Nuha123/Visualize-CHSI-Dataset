#General Clustering
k.max <- 15
data <- as.matrix(HeartTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(2:4)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

dataset <- read.csv("HeartTotalSum.csv")
# Fitting K-Means to the dataset
set.seed(29)
kmeans = kmeans(dataset[2:4], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"ClusteredHeart.csv",row.names=FALSE)
p <- read.csv("ClusteredHeart.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(HeartTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(2)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[2], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 25-44 Heart.csv",row.names=FALSE)
p <- read.csv("Age 25-44 Heart.csv")




#Clustering based on 
k.max <- 15
data <- as.matrix(HeartTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(3)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[3], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 45-64 Heart.csv",row.names=FALSE)
p <- read.csv("Age 45-64 Heart.csv")


#Clustering based on 
k.max <- 15
data <- as.matrix(HeartTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(4)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

kmeans = kmeans(dataset[4], centers = 4)
y_kmeans = kmeans$cluster
print(y_kmeans)
t<-cbind(dataset[1],y_kmeans,deparse.level = 1)
q <- data.frame(t)
write.csv(q,"Age 65+ Heart.csv",row.names=FALSE)
p <- read.csv("Age 65+ Heart.csv")


