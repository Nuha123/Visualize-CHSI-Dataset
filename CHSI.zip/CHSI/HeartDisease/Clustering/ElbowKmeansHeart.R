k.max <- 15
data <- as.matrix(HeartTotalSum)
wss <- sapply(1:15,function(k){kmeans(na.omit(data[,c(2:4)]), k, nstart=50,iter.max = 15 )$tot.withinss})
plot(1:k.max, wss,
     type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")



#number of optimal clusters will be 4 according to scree plot 
clust = kmeans(na.omit(data[,c(2:4)]),centers = 4,iter.max = 20)
clust$cluster
o=order(clust$cluster)      #Sorts the cluster on basis of number clustering
# to which cluster they are falling
a1 = which(clust$cluster==1)
a2 = which(clust$cluster==2)
a3 = which(clust$cluster==3)
a4 = which(clust$cluster==4)
d1=data[,c(1,2)]# that has column 1 n 2 of data
death_one = d1[a1,]
death_two = d1[a2,]
death_three = d1[a3,]
death_four = d1[a4,]
