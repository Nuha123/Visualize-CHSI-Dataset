# Importing the libraries
import pandas as pd
import sklearn


# Importing the dataset
dataset = pd.read_csv('ClassificationHeart.csv')
X = dataset.iloc[:, [1,2,3,4,5,6]]
y = dataset.iloc[:, 7]
feature_cols = ['s1', 's2','s3','s4','s5','s6']

# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

# Fitting classifier to the Training set
from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)
print(X_test)
print(y_pred)


