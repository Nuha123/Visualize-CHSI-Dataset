dataset <- read_xlsx("CancerAgeWise.xlsx")
data <- dataset[1]
n<-nrow(data)
print(n)
a<-c()
#state names
for (i in 1:n) {
  a[i]<-data$CHSI_State_Name[i]
}
#print(a)
final<-unique(a)
print(final)
k<-1
s1<-c()
s2<-c()
s3<-c()
s4<-c()
s5<-c()
s6<-c()
s7<-c()
s8<-c()
s9<-c()
s10<-c()
s11<-c()
s12<-c()
s13<-c()
s14<-c()
s15<-c()
s16<-c()
s17<-c()
s18<-c()
s19<-c()
s20<-c()
sum1<-0
sum2<-0
sum3<-0
sum4<-0
sum5<-0
sum6<-0
sum7<-0
sum8<-0
sum9<-0
sum10<-0
sum11<-0
sum12<-0
sum13<-0
sum14<-0
sum15<-0
sum16<-0
sum17<-0
sum18<-0
sum19<-0
sum20<-0
for(i in 1:51){
  for(j in k:n){
    if(final[i]==data$CHSI_State_Name[j]){
      if(dataset$B_Wh_Cancer[j]>0)
        sum1<-sum1+dataset$B_Wh_Cancer[j]
      if(dataset$B_Bl_Cancer[j]>0)
        sum2<-sum2+dataset$B_Bl_Cancer[j]
      if(dataset$B_Ot_Cancer[j]>0)
        sum3<-sum3+dataset$B_Ot_Cancer[j]
      if(dataset$B_Hi_Cancer[j]>0)
        sum4<-sum4+dataset$B_Hi_Cancer[j]
      if(dataset$C_Wh_Cancer[j]>0)
        sum5<-sum5+dataset$C_Wh_Cancer[j]
      if(dataset$C_Bl_Cancer[j]>0)
        sum6<-sum6+dataset$C_Bl_Cancer[j]
      if(dataset$C_Ot_Cancer[j]>0)
        sum7<-sum7+dataset$C_Ot_Cancer[j]
      if(dataset$C_Hi_Cancer[j]>0)
        sum8<-sum8+dataset$C_Hi_Cancer[j]
      if(dataset$D_Wh_Cancer[j]>0)
        sum9<-sum9+dataset$D_Wh_Cancer[j]
      if(dataset$D_Bl_Cancer[j]>0)
        sum10<-sum10+dataset$D_Bl_Cancer[j]
      if(dataset$D_Ot_Cancer[j]>0)
        sum11<-sum11+dataset$D_Ot_Cancer[j]
      if(dataset$D_Hi_Cancer[j]>0)
        sum12<-sum12+dataset$D_Hi_Cancer[j]
      if(dataset$E_Wh_Cancer[j]>0)
        sum13<-sum13+dataset$E_Wh_Cancer[j]
      if(dataset$E_Bl_Cancer[j]>0)
        sum14<-sum14+dataset$E_Bl_Cancer[j]
      if(dataset$E_Ot_Cancer[j]>0)
        sum15<-sum15+dataset$E_Ot_Cancer[j]
      if(dataset$E_Hi_Cancer[j]>0)
        sum16<-sum16+dataset$E_Hi_Cancer[j]
      if(dataset$F_Wh_Cancer[j]>0)
        sum17<-sum17+dataset$F_Wh_Cancer[j]
      if(dataset$F_Bl_Cancer[j]>0)
        sum18<-sum18+dataset$F_Bl_Cancer[j]
      if(dataset$F_Ot_Cancer[j]>0)
        sum19<-sum19+dataset$F_Ot_Cancer[j]
      if(dataset$F_Hi_Cancer[j]>0)
        sum20<-sum20+dataset$F_Hi_Cancer[j]
      j<-j+1
    }
    else{
      k<-j
      break
    }
  }
  
  s1[i]<-sum1
  s2[i]<-sum2
  s3[i]<-sum3
  s4[i]<-sum4
  s5[i]<-sum5
  s6[i]<-sum6
  s7[i]<-sum7
  s8[i]<-sum8
  s9[i]<-sum9
  s10[i]<-sum10
  s11[i]<-sum11
  s12[i]<-sum12
  s13[i]<-sum13
  s14[i]<-sum14
  s15[i]<-sum15
  s16[i]<-sum16
  s17[i]<-sum17
  s18[i]<-sum18
  s19[i]<-sum19
  s20[i]<-sum20
  sum1<-0
  sum2<-0
  sum3<-0
  sum4<-0
  sum5<-0
  sum6<-0
  sum7<-0
  sum8<-0
  sum9<-0
  sum10<-0
  sum11<-0
  sum12<-0
  sum13<-0
  sum14<-0
  sum15<-0
  sum16<-0
  sum17<-0
  sum18<-0
  sum19<-0
  sum20<-0
}
t<-cbind(final,s1,deparse.level = 1)
t<-cbind(t,s2,deparse.level = 1)
t<-cbind(t,s3,deparse.level = 1)
t<-cbind(t,s4,deparse.level = 1)
t<-cbind(t,s5,deparse.level = 1)
t<-cbind(t,s6,deparse.level = 1)
t<-cbind(t,s7,deparse.level = 1)
t<-cbind(t,s8,deparse.level = 1)
t<-cbind(t,s9,deparse.level = 1)
t<-cbind(t,s10,deparse.level = 1)
t<-cbind(t,s11,deparse.level = 1)
t<-cbind(t,s12,deparse.level = 1)
t<-cbind(t,s13,deparse.level = 1)
t<-cbind(t,s14,deparse.level = 1)
t<-cbind(t,s15,deparse.level = 1)
t<-cbind(t,s16,deparse.level = 1)
t<-cbind(t,s17,deparse.level = 1)
t<-cbind(t,s18,deparse.level = 1)
t<-cbind(t,s19,deparse.level = 1)
t<-cbind(t,s20,deparse.level = 1)
bs <- data.frame(t)
write.csv(bs,"CancerSum.csv",row.names=FALSE)
nk <- read.csv("CancerSum.csv")
print(nk)


sum<-nk[2]+nk[3]+nk[4]+nk[5]
t<-cbind(final,sum,deparse.level = 1)

sum<-nk[6]+nk[7]+nk[8]+nk[9]
t<-cbind(t,sum,deparse.level = 1)

sum<-nk[10]+nk[11]+nk[12]+nk[13]
t<-cbind(t,sum,deparse.level = 1)

sum<-nk[14]+nk[15]+nk[16]+nk[17]
t<-cbind(t,sum,deparse.level = 1)

sum<-nk[18]+nk[19]+nk[20]+nk[21]
t<-cbind(t,sum,deparse.level = 1)

bs<-data.frame(t)
write.csv(bs,"CancerTotalSum.csv",row.names = FALSE)
nk1<-read.csv("CancerTotalSum.csv")

